# Design Information for the Quiz Application

This Application is designed to let students to not just participate in quizzes but also lets them to create their own quiz, which can be used to participate by other students. Its main features are handled in the design and explained in "Italics" below,

1.  When starting the application, a user can choose whether to (1) log in as a specific student or (2) register as a new student.
To register as a new student, the user must provide the following student information:
A unique username
A major
A seniority level (i.e., freshman, sophomore, junior, senior, or grad)
An email address

> register a student by creating a student object and populating it's attributes. For registering the student, method `registerStudent()` is used for by transferring all the input parameters mentioned above in association with Student class.
Unique username -> userName
Major -> major
seniority level -> seniority
email address -> emailID
>login and get the student object with all respective details, method `loginStudent()` is used for this.

2. The newly added student is immediately created in the system.
> After registration newly added student is created in the system using `addStudent()` method with aforesaid input parameters.

3. For simplicity, there is no password creation/authentication; that is, selecting or entering a student username is sufficient to log in as that student.
Also for simplicity, student and quiz information is local to a device.

>Password authentication is not handled in the application. Unique username defined by the student would be used for all quiz operations. No, seperate database classes are created as the information related to quiz is local to device.

4. The application allows students to (1) add a quiz, (2) remove a quiz they created, (3) practice quizzes, and (4) view the list of quiz score statistics.
>In the student class, using the student's user name, student can add a quiz or remove a quiz by using the methods `addQuiz()` and `removeQuiz()`. `addQuiz()` returns a boolean indicating whether or not a quiz is added for a given student, whereas `removeQuiz()` returns void, this method also makes sure the score of removed quiz is removed too. Before removing a quiz a check will be made using method `checkifQuizowner()` if it is the quiz owner who is deleting it, restricting other students from removing the quiz who did not create the quiz.
>Students can also practice quizzes created by other students, this is handled by creating a seperate class PracticeQuiz. 
> List of quiz score statistics can be displayed using display methods in Quizstats class.

5. To add a quiz, a student must enter the following quiz information:
Unique name
Short description
List of N words, where N is between 1 and 10,  together with their definitions 
List of N * 3 incorrect definitions, not tied to any particular word, where N is the number of words in the quiz.

>It is handled by creating a `Quiz` class which is in composition with class `QuestionWord`, which again is in composition with `Options` class. Each Quiz class can have 1 to 10 question words, which is depicted in multiplicity on compsotion between Quiz and QuestionWord class.
> Each question word has a set of 4 options. Which contains one correct definition and 3 incorrect definitions. This criteria is achieved by using two methods `setWordDef()` and `setIncorrectDef()` and also by setting `countIncorrectDef`to integer 3. Input string `wordText` is passed to the options class to set the options using `setOpions()` method for that particular question word, this method all correct and Incorrect definitions to the word passed as input.

6. To remove a quiz, students must select it from the list of the quizzes they created. Removing a quiz must also remove the score statistics associated with that quiz.
>Method `removeQuiz()', with input parameter passed as quiz name is used to handle this requirement. Only the student who created the quiz will be able to delete with the help of `checkifQuizowner()` method as discussed previously.

7. To practice a quiz, students must select it from the list of quizzes created by other students.
> List of quizzes are made available in the PracticeQuiz class, which enables user to pick a quiz and participate. A check is made using method `checkifQuizisothers()` to restrict if the student is trying to participate in his own creation of quiz.

8. When a student is practicing a quiz, the application must do the following:
Until all words in the quiz have been used in the current practice session: 
Display a random word in the quiz word list.
Display four definitions, including the correct definition for that word (the other three definitions must be randomly selected from the union of (1) the set of definitions for the other words in the quiz and (2) the set of incorrect definitions for the quiz. 
Let the student select a definition and display “correct” (resp., “incorrect”) if the definition is correct (resp., incorrect).

>As the correct and Incorrect definitions are set at the question level, the same would be displayed when a student tries to practice a quiz using `ResultView` class. `takeQuiz()` method enables the student to participate in quiz which is not created by him. `showQuestion()` method displays the question. Method `viewResponse()` of Class `ResultView` is used to display the correctness(Incorrectness) of the answer using the `ResultView` class. 

9. After every word in the quiz has been used, the student will be shown the percentage of words they correctly defined, and this information will be saved in the quiz score statistics for that quiz and student.

> Question response is displayed using method `viewResponse()` method of class 'ResultView`. Percentage of correct words after a quiz is displayed by method `viewResultbypercentagepostquiz()` from same class above. Class `QuizScore` is used to set the score along with the time stamp for a particular student. This in turn is saved in the `QuizStats` class, this is achieved by using an aggregation relationship between `QuizScore` and `QuizStats`. Ellipsis in the class `QuizScore` depict the getter classes and display classes for the corresponding setter classes shown in the class. 

10. The list of quiz score statistics for a student must list all quizzes, ordered based on when they were last played by the student (most recent first). Clicking on a quiz must display (1) the student’s first score and when it was achieved (date and time), (2) the student’s highest score and when it was achieved (date and time), and (3) the names of the first three students to score 100% on the quiz, ordered alphabetically.

> Above requirement is handled by the `QuizStats` class. It takes into account a list of scores `qzlist:List<Quizscore> ` achieved by various students. For a particular student it displays his first score using method `displayStudentlstscore(List <qzlist>,stname:String)`. Highest score is obtained by method `displayStudentHighScore(List<qzlist>, stname:String) `. Top 3 highest scores ordered alphabatically are obtained by method ` displayTop3Highscoresorderedalphabatically()`. Alls scores of a student are displayed through method `displayStudentallscores()`.

11. The user interface must be intuitive and responsive.
>This is not handled in the design as it is a GUI feature, and it is not in scope of requirement.

12. The performance of the game should be such that students do not experience any considerable lag between their actions and the response of the application.
> Since all the data is stored in a local device and also because multiple students cannot access the Quiz app at the same time, the response time of the application is faster.
