## Design Information

#### Register 

Users can register as a student using this class. This class let users to be aprt of the system and provide access to the functionalities that are provided by the system. This class will prompt users to input information and then save the student in the system.

#### Login
This class contains student username and it will let the student login once the student input the username.

#### Student
This class quiz information specific to the logged in student.

#### AddQuiz 
This class let student add quizes. It will get the quiz information from the student and it will validate the inputs and then the new quiz will be added to the system.

#### RemoveQuiz
This class contains the list of the quizes a student create and it will allow student to select from the list and remove. It will also remove the quiz score statistics associated with the logged in student.

#### PracticeQuiz

This class contain quizes from other student. It allow student to select quiz from other student and practice.
#### PracticeSession
This class contains words associated with the quiz that student selected to practice. It will provide display the words with four options. One of the option will be correct and other three will be display randomly. This class will also dshow the result of that quiz and the score will be saved in quiz score statistics.

#### QuizStatistics

This class contains an array of all quizes that was taken by the logged in student. It will also have the first score, highest score, top 3 student's name depending on the highest score of 100 and it will display the date and time associated with the quiz. This class will order the quizes based on last played. 