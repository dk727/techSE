1.
My `student` object contains `username`, `major`, `seniority` and `email_address` as required. 

To realize the login and signup, I add a global hashSet `studentSet` to maintain all the student signed up in the system. If student is “signup” to the system, we need to make sure this name does not already exist in the studentSet and add this name to the set. For login operation, if the student name exists in the `studentSet`, then we allow this student to login.

2.
I have three methods, `addQuiz`, `removeQuiz` and `practiceQuiz` which are connect `quiz` class and `student` class. And `viewScore` method to connect `score` class and `student` class.


3.
I define `quiz` class to maintian all the fields needed, which are `quiz name` and `description`.

And I have a word with correct definition pool and incorrect definition pool.

To be clear, I also use `question` class to connection quiz and word (word definition). Each quesition has a word with correct definition and three incorrect definition from pool. And a `quiz` contains N `questions`.

To better keep the quiz information, I create a global variable `quizMap` whose key is `studentName` and value is a set of quizzes created by him/her.

4.
First we can find the set of quizzes from `quizMap` by using `studentName` as key.

Quiz can be removed the set.

For score statistics, I have two maps to keep them.

One is named `scoreStatisticsByQuizname`, key is `quizName` and the value is a set of `scoreStatistics` with this `quizName`; the other one is named `scoreStatisticsByStudentname`, key is `studentName` and the value is a set of scoreStatistics which are taken by this student.

So to remove `scoreStatistics` for that quiz, first we need to remove key-value pair from `scoreStatisticsByQuizname` if `key == quizName`. Then we should traverse all the `scoreStatistics` in value of `scoreStatisticsByStudentname` and remove the `scoreStatistics` if its quizname equals to the removed one. 

5.
First we can grap all the quizzes from `quizMap` except when `quizMap.key == student.name` to form a quiz list.

A student can practice any quiz from the quiz list.

6.
Just as what I metioned in No.3. I have word with` correct definition class` and `incorrect definition class` and `question class`. 

In word with correct definition class and incorrect definition class, I have a field named `ifUsed` to record if this definition(word) is already used, thus we can display a word which `isUsed` flag is false and we can know if all the words is used. Besides, every question has a field named `ifCorrect` to show if student's answer is correct or not.

By calculating the correct answered queation, we can get corret percentage for this quiz. 

If this student have not taken this quiz before, we filled every field in the `scoreStatistics` and add it to two `scoreStatistics` maps. Otherwise, we need to update `scoreStatistics` object in the maps.

7.
First I give a `score` class which includes two fields `scorePercent` and `date`. Then I have a `scoreStatistics` class which has all the field like, `quizName`, `studentName`, `firstScore`, `highestScore` and list of first three students to score 100%.

To display a list of `scoreStatistics`, I use `student.name` as key to search from the map and order them.

8 and 9 can not be showed by design and I will handle them when implement this application.