# Design Discussion 

### Design 1  
[![N|Solid](https://github.gatech.edu/storage/user/23833/files/de154062-c2ad-11e8-8dbb-2ec9a3a49d9a)](https://nodesource.com/products/nsolid)

#### Pros 
* Define pretty clear classes and the clear relationship between all the classes.
* My design can satisify all the requirements in a relatively efficient way by using global maps.

#### Cons 
* I did not provide operations in the design diagram and I only explain them in the md doc. I feel I need to show some significant methods and operations in the design diagram which makes diagram more readable.
* I did not point out a relationship between classes is composition or realization or aggregation or soon.


### Design 2 
[![N|Solid](https://github.gatech.edu/storage/user/23833/files/8dbd2bfc-c2ad-11e8-84f3-4e783fecbce0)](https://nodesource.com/products/nsolid)

#### Pros 
* Relationships between various classes have been clearly shown.
* Multiple classes have been created to distinguish the important functionalities.
* Functionalities are well elaborated in the md document.

#### Cons 
* Some of the methods like methods to display and to set options for questions were redundant.
* Methods and parameters are elaborate in the UML, which may not be necessary if all the functionalities are mentioned in the md document.



### Design 3 
[![N|Solid](https://github.gatech.edu/storage/user/23833/files/a41bc63e-c2ac-11e8-9d9e-a6f17dc5c09d)](https://nodesource.com/products/nsolid)

#### Pros 
* More details about the functionalities in the design
* Less chances of code duplication due to separated classes based on major functions 

#### Cons 
* Project structure is missing few associations. 
* Too many sub methods/operations 

### Team Design
[![N|Solid](https://github.gatech.edu/storage/user/23833/files/87a6ee5e-c345-11e8-938b-4cc72427389c)](https://nodesource.com/products/nsolid)

* Main commonalities between team design and Individual designs: 
>Our Individual designs and the team design had all the required classes. All design attributes and operations are easy to understand and descriptive. 
* Main differences between team design and Individual designs:
>The main differences between team design and Individual designs are the information that we missed in our individual designs. For example, our individual designs were missing either operations, associations or attributes. We combined the missing parts from our individual designs to the team design. Individual designs do not satisfy all the requirements whereas team design meets all the requirements. 


### Summary 
1. After considering  various designs done by the team members, we got a good understanding of how things can be done better in the final design. Some of the main goals we could achieve by discussing about different designs are,
 * We were able to reduce method and class redundancy.
 * Were able to come up with a better plan regarding data storage by using Hashmaps.
 * Were able to come up with a design that helps in creating an app that can take lesser time to respond. Instead of storing all the    quiz records for a student for a quiz, we decided to store only the first and highest scores for a student, which in turn makes the application more faster.
 * Were able to decide on better validation checks within the methods, which in turn helps us in handling the exceptions efficiently.
 * We could do a better encapsulation of student information by maintaining seperate classes for register and login togethar and  student.

2. After having various design discussions, our design has definitely evolved during the course of time. We were able to put together several aspects of the requirement at ease due to our collaboration, which otherwise would have been a difficult task to do it all on our own. 

3. Team work saved us a lot of time in coming up with a final design, since each of us worked on a different part of the design and finally combined our work. Also it became a lot easier to get to the final outcome since the team mates were co-operative.


