# Use Case Model


**Author**: Team 59

## 1 Use Case Diagram
[![N|Solid](https://github.gatech.edu/storage/user/23833/files/cae84e8a-c8c0-11e8-8658-cbbef526f51d)](https://nodesource.com/products/nsolid)

## 2 Use Case Descriptions

# Login
- *Requirements: This use case allow users to login to the system.* 
- *Pre-conditions: Must provide an userName*
- *Post-conditions: User must be logged in once the login use case is run.*
- Scenarios: 
[![N|Solid](https://github.gatech.edu/storage/user/23833/files/bf8134b2-c69f-11e8-9da4-01defb75f393)](https://nodesource.com/products/nsolid)

# Register 
- *Requirements: This use case will allow users to create an account*
- *Pre-conditions: Muct provide the useName, major, Seniority level and email address*
- *Post-conditions: new student must be created in the system once the use case is run.*
- Scenarios:
[![N|Solid](https://github.gatech.edu/storage/user/23833/files/c576033e-c8c5-11e8-8d18-70463f72e0a5)](https://nodesource.com/products/nsolid)

# AddQuiz 
- *Requirements: This use case allow user to add quizes*
- *Pre-conditions: Must provide all required inputs*
- *Post-conditions: A new quiz must be added to the Quiz list once the use case is run.*
- Scenarios: 
[![N|Solid](https://github.gatech.edu/storage/user/23833/files/d82ca14c-c6a2-11e8-8329-4622b19449ed)](https://nodesource.com/products/nsolid)

# RemoveQuiz 
- *Requirements: This use case allow the user to remove quiz from the system.*
- *Pre-conditions: Must select from the list of quizes*
- *Post-conditions: selected quiz/quizes must be deletd from the system once the use case is run.*
- Scenarios: 
[![N|Solid](https://github.gatech.edu/storage/user/23833/files/8453bef4-c8c1-11e8-8e7e-64b4b326ab57)](https://nodesource.com/products/nsolid)

# Practice Quiz
- *Requirements: This class will allow the user to select quiz from other student and practice*
- *Pre-conditions: User must select a quiz*
- *Post-conditions: Must display a practice session for the selected quiz*
- Scenarios:
[![N|Solid](https://github.gatech.edu/storage/user/23833/files/a4a9469a-c71f-11e8-8390-073705302eda)](https://nodesource.com/products/nsolid)

# Show Score
- *Requirements: This will show score percenatge after finishing a quiz.*
- *Pre-conditions: Finished a quiz first*
- *Post-conditions: Show the correct score percentage after quiz submitted.*
- Scenarios:
[![N|Solid](https://github.gatech.edu/storage/user/23800/files/e0837e0e-c8de-11e8-9b2f-0f230f7bd4e9)](https://nodesource.com/products/nsolid)

# Score Statistics
- *Requirements: This is used to display score statistics based on certain filter.*
- *Pre-conditions: A student must login first.*
- *Post-conditions Must display following things id this quizzes are taken by login student and ordered by date.
     (1) the student’s first score and when it was achieved (date and time),
     (2) the student’s highest score and when it was achieved (date and time),
     (3) the names of the first three students to score 100% on the quiz, ordered alphabetically.
     Only need to display the names of the first three students to score 100% on the quiz (ordered alphabetically) for the quizzes are not taken by login student in any order.*
- Scenarios: 
[![N|Solid](https://github.gatech.edu/storage/user/23800/files/7c214e02-c8d2-11e8-9f7d-568af14f81d6)](https://nodesource.com/products/nsolid)

# Generate Question 
- *Requirements: This use case will diplay randomly generated question to the user. It will also display a correct option and three incorrect option associated with word*
- *Pre-conditions: Student must click on the start button in practice quiz activity after selecting the quiz*
- *Post-conditions: Display generated question once the use case is run.*
- Scenarios: 
[![N|Solid](https://github.gatech.edu/storage/user/23833/files/77a4e1ba-c722-11e8-9cc1-979472fc9a91)](https://nodesource.com/products/nsolid)

# Validations 
- *Requirements: This use case validates inputs when user register, login and add quiz*
- *Pre-conditions: User must provide required inputs*
- *Post-conditions: A new student will be added if register validateion pass, studuent will be able to access the system funtionalities if login validation pass and a new quiz will be added if the quiz inputs are correct.*
[![N|Solid](https://github.gatech.edu/storage/user/23833/files/2f6d7c76-c728-11e8-80de-49d6b1b1f012)](https://nodesource.com/products/nsolid)
