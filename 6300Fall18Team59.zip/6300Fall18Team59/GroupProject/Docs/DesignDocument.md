# Design Document

*This is the template for your design document. The parts in italics are concise explanations of what should go in the corresponding sections and should not appear in the final document.*

**Author**: \<person or team name\>

## 1 Design Considerations

*The subsections below describe the issues that need to be addressed or resolved prior to or while completing the design, as well as issues that may influence the design process.*

### 1.1 Assumptions

*Describe any assumption, background, or dependencies of the software, its use, the operational environment, or significant project issues.*

1. If a student is newly registered, he/she will be auto loged in.
2. We assume application's time-out is 5s.
3. If a student quits/closes the quiz, then we will remove the partial record.
4. Multiple device size compatibility and device resolutions can impact on the design of the system.
5. We are going to use Firebase as our database.


### 1.2 Constraints

*Describe any constraints on the system that have a significant impact on the design of the system.*

1. The device should support Android and should have latest version.
2. The device should have enough storage to install our app(over 100MB).
 


### 1.3 System Environment

*Describe the hardware and software that the system must operate in and interact with.*

The device should be able to get connected to Internet.

## 2 Architectural Design
[![N|Solid](https://github.gatech.edu/storage/user/23833/files/22117104-c8c7-11e8-934a-be5e0ea2292c)](https://nodesource.com/products/nsolid)

### 2.1 Component Diagram

[![N|Solid](https://github.gatech.edu/storage/user/23833/files/2bc1622c-c8c7-11e8-910f-3c4ecda2660d)](https://nodesource.com/products/nsolid)

### 2.2 Deployment Diagram
[![N|Solid](https://github.gatech.edu/storage/user/23833/files/2edfd434-c8c7-11e8-998b-47b0058e8ca1)](https://nodesource.com/products/nsolid)

## 3 Low-Level Design

*Describe the low-level design for each of the system components identified in the previous section. For each component, you should provide details in the following UML diagrams to show its internal structure.*

### 3.1 Class Diagram

*In the case of an OO design, the internal structure of a software component would typically be expressed as a UML class diagram that represents the static class structure for the component and their relationships.*

![lowleveldesign_quizapp](https://github.gatech.edu/storage/user/22735/files/a1e9a0cc-c8ef-11e8-871e-fa85696a80bd)

### 3.2 Other Diagrams

*<u>Optionally</u>, you can decide to describe some dynamic aspects of your system using one or more behavioral diagrams, such as sequence and state diagrams.*

## 4 User Interface Design
[![N|Solid](https://github.gatech.edu/storage/user/23833/files/9fe3b5c0-c74a-11e8-810a-66918f4bc1a9)](https://nodesource.com/products/nsolid)

[![N|Solid](https://github.gatech.edu/storage/user/23833/files/b821c0fa-c74a-11e8-90ee-93740744f454)](https://nodesource.com/products/nsolid)

[![N|Solid](https://github.gatech.edu/storage/user/23833/files/d56680f6-c74a-11e8-9fed-07f60358d972)](https://nodesource.com/products/nsolid)

[![N|Solid](https://github.gatech.edu/storage/user/23833/files/e5bae992-c74a-11e8-8d51-dcc693a46525)](https://nodesource.com/products/nsolid)

[![N|Solid](https://github.gatech.edu/storage/user/23833/files/1bf43dce-c74b-11e8-8525-5100328abbf7)](https://nodesource.com/products/nsolid)

[![N|Solid](https://github.gatech.edu/storage/user/23833/files/f730fa36-c74a-11e8-85a2-d433c5060071)](https://nodesource.com/products/nsolid)

[![N|Solid](https://github.gatech.edu/storage/user/23833/files/35dbbb04-c74b-11e8-8b50-89cbeee0761d)](https://nodesource.com/products/nsolid)

[![N|Solid](https://github.gatech.edu/storage/user/23833/files/5699cbec-c74b-11e8-9369-af2ca4c104ba)](https://nodesource.com/products/nsolid)

[![N|Solid](https://github.gatech.edu/storage/user/23833/files/48289d18-c74b-11e8-9991-66b8d3ce75a0)](https://nodesource.com/products/nsolid)







