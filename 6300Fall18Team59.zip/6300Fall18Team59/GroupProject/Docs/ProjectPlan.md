# Project Plan
**Author**: Team 59 

## 1 Introduction
SDP quiz app provides an interactive system that allow users to learn easily. This app let user to login, register, add quiz, remove quiz, practice quiz and user can also view score statistics. 

## 2 Process Description
### Login Activity 
- *Login (verb)*
- Activity description: This activity prompts the users to enter userName. Once the username is provided, access to the system functionalities will be granted to the users.  
- *Entrance criteria: UserName*
- *Exit criteria: Users will be redirected to the quiz activity if the login method validation pass. We will know when the action is completed successfully because users will be directed to the quiz activity only when it pass the validation in login method.*

### Register Activity 
- *Register (verb)*
- *Activity description: This activity will allow new users to register. It will prompt users to input Username, Major, Seniority level and email address. Once the required information is provided users will be directed to the login activity*
- *Entrance criteria: Username, Major, Seniority level and email address*
- *Exit criteria: Users will be redirected to the login activity if the register method validation pass. We will know when the action is completed successfully because users will be directed to the login activity only when it pass the validation in register method.*

### Quiz Activity
- *Quiz (verb)*
- *Activity description: This activity will provide user option to add quiz, remove quiz, practice quiz or view quiz statistics.*
- *Entrance criteria:  Must select an option to perform an action*
- *Exit criteria: User will be directed to the selected activity. We will know when the action is completed successfully because users will be directed to the selected activity only when it pass the validations*

### AddQuiz Activity 
- *AddQuiz(verb phrase)*
- *Activity description: This activity will allow user to add new quiz to the system*
- *Entrance criteria: Quiz Name, Description, words, correct definitions and incorrect definitions*
- *Exit criteria: User must click on the add button in order to add words and definitions. We will know when the action is completed successfully becausDalyae new word will be added in the list and it will show in the add quiz activity. ValidatequizCheck will check if user input meets the requirements and once the requirements are complete, new quiz will be added to the system.*

### RemoveQuiz Activity 
- *RemoveQuiz (verb phrase)*
- *Activity description: This activity will allow user to select a quiz and remove from the system.*
- *Entrance criteria: user must select a quiz and click remove.*
- *Exit criteria: Selected quiz will be deleted from the system. We will know when the action is completed successfully because users will get a prompt if removeQuiz method is successfull and the deleted quiz won't appear in the quiz list*

### PracticeQuiz Activity 
- *PracticeQuiz (verb phrase)*
- *Activity description: This activity will allow user to select a quiz and practice.*
- *Entrance criteria: user must select a quiz and click start.*
- *Exit criteria: Users will be directed to the practice quiz session once they select a quiz and click on start. We will know when the action is completed successfully because practiceQuiz method will direct user to practioce session activity only when the validation pass*

### PracticeSession Activity
- *PracticeSession (verb)*
- *Activity description: This activity will display the selected quiz from practiceQuiz activity and displayQuestion method will generate the questions based on the requirments. Options will be displayed in radio buttons so that user can select the answer. Once all questions are answered users will be able to submit the quiz.* 
- *Entrance criteria: Users must select at least one answer for each question and click submit.*
- *Exit criteria: Score of the quiz will be shown. We will know when the action is completed successfully because users will be able to see the results only after clicking submit. Submit method will also validate if at least one answer is selected for each question. 

### ScoreStatistics Activity 
- *ScoreStatistics (verb)*
- *Activity description: This activity will provide quiz score statistics. It will display the list of quizes that the logged in user created. It will also show the first score with date and time, highest score with date and time and top 3 student name with score 100. Quizes will be displayed based on last play time and top 3 student name will be ordered alphabetically.*
- *Entrance criteria: User must select a quiz to view the quiz statistics.*
- *Exit criteria: Quiz statistics will be shown once a quiz is selected.We will know when the action is completed successfully because users will be able to see the statistics only when DisplayOnClickOfQuiz method validation pass. 

## 3 Team

*Describe the team and their roles (include at least 4 roles, there may be more roles than there are team members)*

- *Team Members: Sai Prasuna Avala, Xuesong Wang and Dalya Khatun*

Role | Descriptions
--- | ---
Project Manager	| Dalya Khatun
Developer |  Sai Prasuna Avala, Xuesong Wang and Dalya Khatun
Tester  | Sai Prasuna Avala, Xuesong Wang and Dalya Khatun
Documentation | Sai Prasuna Avala, Xuesong Wang and Dalya Khatun

