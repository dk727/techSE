# Test Plan

## Testing Strategy

#### 1.1  Overall strategy:

We plan to write unit tests to cover all the functions and as many code lines as possible to get a 100% function coverage and above 90% line coverage. In addition, system tests are very important. We would use these test cases to make sure our application is usable and meet all the requirements. We are going to add all the tests to regression test suites and try to run it every time we have upgrade or fix a bug to make sure our fix or upgrade does not break things seems unrelated.

Unit-testing: shared
System-testing: shared
Regression-tesing: shared

#### 1.2 Test Selection:
We are going to use white-box techniques to write unit-tests and black-box to write system-tests as well as integration tests.


#### 1.3 Adequacy Criterion:

We would use unit tests to pursue high structural coverage and use system tests to pursue high functional coverage.

#### 1.4 Bug Tracking:

 We are going to have a table with bug number and enhancement(development) number. And each bug and enhancement(development) has same structure which has description, what kind of tests have done and summary. We can know our work flow by checking this table and monitor if every part of code has been covered by tests.

#### 1.5 Technology:
 We are going to use JUnit.

## Test Cases
#### Non-Functional System test cases:
 
 |Test case No|Purpose|Steps to perform test|Expected result|Actual result|pass/fail|Difficult|Impossible|
   |--- |--- |--- |---|--- |--- |--- |---|
  |1|Application long launch time. App should notify the user about long launch time.|1. Launch App.            2. Observe launch time.|If application launch is taking longer than 5secs then message must be displayed to notify the user.||||
   |2|Memory usage. App must handle out of memory exceptions during App execution.|1. Operate app in a way so as to force the App to write data into the system.                     2. Exit the App.            3. Fill system to its capacity.                         4. Operate the application, explore functions and screens.  |App should handle out of memory exceptions correctly. Advisory warning to user has to be given about lack of memory when file is trying to be stored.||||
   |3|Incoming phone call while application in use. It should be possible to resume from the same point in the Application at the end of the call, or a logical re-starting point.|1. While Application is running, make an incoming call to the test handset.  2. Accept the incoming call. 3. End the incoming call. 4. Return to the Application|1. The incoming call dialog is shown. 2. After the call is taken and ended, the Application should resume to either the point of interruption, or a point which neither inconveniences the user nor causes data loss.||||
   |4|Readability. Ensure that app content is readable|1. All screen content must be clear (e.g. screen not crowded with content) and readable to the naked eye regardless of information displayed, or choice of font, colour scheme etc.|The application content should be readable. If there are issues they should be graded whether Difficult or Impossible. ||||
   |5|User Interface read time. Should have enough time to read the content.|Use the app, moving between screens.|Each screen must be visible for the time necessary to comfortably read all its information. If the screen is not visible for an appropriate time the issue should be graded whether difficult or impossible.||||
   |6|User interface screen repainting.|Use the app, moving between screens.|1. The Application screens must be correctly repainted, including cases when dialog boxes are dismissed. 2. There must be no blinking of moving objects and background. If the Application objects overlap they must still render correctly.||||
   |7|User interface consistency|Use the app, moving between screens.|The Application UI should be consistent and understandable throughout, e.g. common series of actions, action sequences, terms, layouts and soft button definitions  that are clear and understandable.||||
   |8|User interface, key layout ease of use|1. Key layout ease of use should only be tested to the extent that it can be influenced by the application. Any limitations of the device that cannot be overcome by application design should be disregarded. 2. Where the device offers multiple input methods (e.g. hardware keypad / touch screen keypad), all the input methods available during normal use of the application should be tested.|1. The buttons should be easy to use. 2. Button usage should be suitable for both a left-handed and right-handed person, within the physical constraints of the device design.||||
   |9|Application speed. The Application works in the device it was targeted for, and it is usable on the device: the speed of the Application is acceptable to the purpose of the Application and must not alter the user experience by being uncontrollable.|1. Use the Application. 2. Observe how fast the Application is to use, and if it is too slow or too fast in its operation for good usability. 3. If the Application behavior is incontrollable due to its speed, such findings needs to be recorded.|1. The Application is usable on the device. 2. The speed of the Application is good enough for the Application usage (i.e. the Application frame rate or response to user input must remain adequate, and must not compromise the Application usage, or prevent the user from progressing normally).||||
   |10|User Interface error messages|Use the application, moving between screens.|1. Any error messages in the Application must be clearly understandable. 2. Error messages must clearly explain to a user the nature of the problem, and indicate what action needs to be taken (where appropriate).||||
   |11|User Interface function progress. Visual indication of the function execution progress|Use the application, moving between screens.|1. Any function selected in the Application should start within 5 seconds. 2. There must be some visual indication that the function is being performed. 3. The visual indication can be anything that the user would understand as a response, e.g. prompting for user input.||||
   |12|User Interface actions while rendering. Application must not perform inappropriate actions while rendering.|Make user input while the Application or handset is busy processing or rendering.|There must be no inappropriate reaction by the Application.||||
   |13|Spelling Errors in UI. The Application must be free of spelling errors. 1. A spelling error is defined as a strict mis-spelling of a word (no grammar or punctuation rules will be applied). 2. The tester will perform the test as specified, but the developer must ensure that this requirement is fulfilled throughout the Application.|1. Launch App in English. 2. Check text appearing in all the screens, including the information dialogues. |No spelling errors must be present in the defined areas.||||
   |14|User Interface Technical text errors. The text in the Application must be clear and readable. The Application must be free of technical text display issues such as: Text cut off / Text overlapping.1. The tester will perform the test as specified below, but the developer must ensure that this requirement is fulfilled throughout the Application. 2. All text in each target language is displayed without corruption, distortion or other display problems. Examples of failures may include a) Menu item text labels incorrectly aligned with cursor b) Button text label over-running the button area or truncated such that its meaning is not clear c) Text over-running or being truncated in other bounded text display areas (e.g. speech bubbles, user interface elements etc) d) Text not wrapping at the edge of the screen resulting in words being cut off e) Multiple pieces of text overlapping each other, or text overlapping user interface elements (but see note 3 below) f) Text being cut horizontally.|1. Launch App in english. 2. Check lables for all the Textviews, radio buttons and buttons belonging to each and every screen |All text located in the specified areas is shown without technical display issues that hinder legibility.||||
   |15|Suspend/Resume from main menu. Ensure  that the Application suspends when at the Application main menu.|1. Launch the Application. 2. Go to the main menu of the Application. 3. Suspend the Application 4. Resume the Application|Application should suspend and resume correctly, and resume at a point that does not impair the user experience.||||
   |16|Suspend while executing. Check for Suspend in the middle of Application execution.|1. Launch the Application. 2. During Application execution, suspend the Application 3. Resume the Application |Application should suspend and resume correctly, and resume at a point that does not impair the user experience.||||
   |17|Check if Application resumes correctly. The objective of this test is to confirm the application’s stability when suspended and resumed multiple times from different locations in one test cycle.|1. Perform Suspend / resume from main menu 2. Resume the Application 4. Perform Suspend while executing 5. Repeat step 2.|The Application resumes to the point where it was suspended, or to a point that does not impair the user experience.||||
   |18|Valid actions for Menu options. Selected and/or changed Application items should invoke valid actions.|1. Start and use application. 2. Observe the results.|All Application items that can be selected and/or changed by user like Add Quiz, Practice Quiz, Remove Quiz and Quizscore Statistics must invoke valid actions according with the Application Specifications.||||
   |19|Application  functionality Sanity check.|1. Launch the Application. 2. Operate the Application, exploring all screens and functions. 3. Document all instances of non-compliance with Application specifications. 4. Document unexpected functionality outside scope of Application specifications|All specific Application functionality such as logic, calculations, scoring, etc. must be implemented correctly.||||
   |20|Application hidden features. The Application does not introduce any hidden features, its functionality set is consistent with the help and it does not harm the data on the device. 1. The tester will perform the test as specified, but the developer must ensure that this requirement is fulfilled throughout the Application. 2. Allowable functions are 1. Cheat codes 2. Unlocking the Application, for example from demo version to a full version. 3. The application must not use any public storage such as the gallery for images( or sounds or similar resources) without informing the user beforehand.|1. Install user’s personal data to the device (for example calendar, contact, to-do, images, text files, documents, etc). 2. Launch the Application. 3. Familiarise yourself with the specification. 4. Use the Application and all of its features for a time period of 15 minutes. 5. Compare the documented Application functionality to the features you find, and what is in the specification.|1. All the features are introduced in the specification, the Application has no hidden features. 2. The data inserted to the device has not been corrupted. 3. The phone bill (or log) does not show any additional communication. 4. The phone bill (or log or data counter, if applicable) does not show an excessive amount of transferred data. 5. The other Applications in the device must run as they did before Application installation.||||
   |21|Scrolling in Application menus.|1. Launch the Application. 2. Use the keypad or other navigation device to scroll vertically and (if applicable) horizontally in the Main menu item list.|This MUST scroll in the menu item list with no adverse effects on the Application.||||
   |22|Application should cope well with simultaneous key presses or multiple touch.|1. Launch the Application. 2. Press combinations of keys simultaneously, from a selection of UP, DOWN, LEFT, RIGHT, CENTER and all other available keys or use multiple touch combinations. Do not use any which intentionally terminate or exit the application, or intentionally launch a function that would invalidate the test.|The Application should not be put into an unusable or incomprehensible state by simultaneous key presses or multiple touches. Any error messages generated should be meaningful.||||
   |23|Application Stability. The Application must not crash or freeze at any time while running on the device.|1. Start to test the Application. 2. Observe the Application behaviour during the testing.|The Application must not freeze or exit unexpectedly at any time.||||
   |24|Application stability after force close by system. Application must preserve sufficient state information to cope with forcible close by the system.|1. Start the Application. 2. Exercise the functionality of the application, like any quiz operations. 3. Press the Home key to return to the Home screen and ensure the application is switched into a paused state. 4. Remove the battery to instantly kill the application, as the system does when dealing with a low memory situation. 5. Restart the handset and open the application again. 6. Check the application is in a usable state and any information built or saved before the close has been retained.|The Application must not lose any information that it implies would be preserved, nor become difficult to use subsequently, as a result of a forcible closure by the system.||||
   |25|Data deletion in Application. The user should always be required to confirm deletion of data while using Remove quiz operation.|1. Launch the Application. 2. Use the Remove Quiz option on main menu. |App needs to notify the user before permanent deletion of quiz data.||||





#### Functional System test cases:

   |Test case|Purpose|Perform|Expected result|Actual result|pass/fail|
   |--- |--- |--- |--- |--- |--- |
   |1|Register with non-exist username||Success, one more username in userlist|||
   |2|Register with existed username|Register this username first|reject|||
   |3|Register without giving major||reject|||
   |4|Register without giving seniority level||reject|||
   |5|Register without giving email||reject|||
   |6|Register with mal-format email||reject|||
   |7|Login after registered|Register this username first|success|||
   |8|Login before registered|Make sure login with non-exist username|reject|||
   |9|Add quiz with without giving description|Login as an student first|reject|||
   |10|Add quiz with without giving -word_definition_correct array/word_definition_Incorrect array|Login as an student first|reject|||
   |11|Add quiz, but the length of word_definition_incorrect array is not three times as the length of word_definition_Incorrect array.|Login as an student first|fail|||
   |12|Add quiz, but the length of word_definition_incorrect array is less than 1 or larger than 10.|login this username first|reject|||
   |13|Add quiz with exist quizname.|Login as an student first|reject|||
   |14|Add quiz, duplicate words exist in word_definition_correct array|Login as an student first|reject|||
   |15|Add quiz, duplicate word definitions exist in word_definition_incorrect array|Login as an student first|reject|||
   |16|Add quiz before login ||reject|||
   |17|Add quiz with valid N, unique quizname, no duplicated word_definition_correct/word_definition_incorrect array and #incorrect_definition:#correct_definition = 3:1|Login as an student first|success, one more quiz in quiz map|||
   |18|Remove quiz created by himself/herself|Login as an student first|Success, one less quiz in the quiz map, one less scoreStatics less in both maps.|||
   |19|Remove quiz which is not created by himself/herself (this might reasonable)|Login as an student first|reject|||
   |20|remove quiz before login (this might reasonable)||reject|||
   |21|Practice a quiz created by himself/herself(might not reasonable)|Login as an student first|reject|||
   |22|Practice a quiz not created by himself/herself.|Login as an student first|Success, scoreStatistics is updated in two scoreStatistics maps.|||
   |23|practice quiz before login (might not reasonable)||reject|||
   |24|Answer correct for a question|Login as an student first|Has correct sign showed|||
   |25|Answer incorrect for a question|Login as an student first|Has incorrect sign showed|||
   |26|During the practice|Login as an student firs(this test needs to do multiple times.)|All the words appear and only appear once(incorrect definition can appear multiple times).|||
   |27|After practice|Login as an student first|Shows correct percentage and scoreStatictics is updated correctly.|||
   |28|List quiz scoreStatictics|Create enough quizzes. Some are already taken by him and some haven’t.|The quizzes not played by S can be displayed in any order and listed behind the quizzes which are played. The quizzes(have not played) has only top3 field and the played quizzes have all the fields.||

####  Unit test cases:

   |Test case|Purpose|Perform|Expected result|Actual result|pass/fail|
   |--- |--- |--- |--- |--- |--- |
   |1| Test Register(username:String,major:String,senioritylevel:String,emailID:String):void|test with all the combination of input|Success,if all the parameters are passed; throw error, if username is not unique; throw error, if one of parameters is missed|||
   |2| Login(username:String):void|test with 1. existed username and 2. nonexist username|1. Success; 2. Fail|||
   |3| addQuiz(username:String):void|test with 1. existed username and 2. nonexist username|1. Success; 2. Fail|||
   |4| viewScoreStats(quizName:String, userName:String):list||return required scoreStatistics list|||
   |5| validQuizCheck(quizName:String, word_definition_Incorrect:String):boolean||return|||
   |6| addQuestion(word:String,word_definition_Incorrect:list,word_definition_correct:list):void|run this function for length of word_definition_correct times|every word and correct definition should appears and only apear once|||
   |7| selectQuizFromOtherStudent(userName:String):list||return all the quizzes other than created by this student|||
   |8| showResult_SelectedDefinitionCorrectorIncorrect(word:String,def:String):String||return all the quizzes other than created by this student|||
   |9|showCorrectlyDefinedWordPercentage(subScoreList:List<Integer>):score||Return correct number based on input list|||
   |10|saveInQuizScoreStatisticsandStudent(score:Score,quizName:String,userName:String):void||Global scoreStatistics maps get updated|||

