package edu.gatech.seclass.sdpvocabquiz;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class Student extends AppCompatActivity {
    ListView listView;
    FirebaseDatabase database;
    DatabaseReference ref;
    ArrayList<String> list;
    ArrayAdapter <String> adapter;
    Quiz quiz;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home);


    }

    public void goToRemoveActivity(View view) {
        setContentView(R.layout.removequiz);

        quiz = new Quiz();

        listView = (ListView) findViewById(R.id.listViewQuiz);
        database = FirebaseDatabase.getInstance();
        ref = database.getReference("Test");
        list = new ArrayList<>();
        Button Remove_btn = (Button) findViewById(R.id.Remove_btn);
        adapter = new ArrayAdapter<String>(this, R.layout.quiz_info, R.id.quizInfo, list);
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                for(DataSnapshot ds : dataSnapshot.getChildren())
                {
                    quiz = ds.getValue(Quiz.class);
                    list.add(quiz.getName().toString()+ "\n" + quiz.getDescription().toString());
                    adapter.notifyDataSetChanged();
                }
                listView.setAdapter(adapter);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        listView.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                DatabaseReference dr = FirebaseDatabase.getInstance().getReference();
            }
        });
    }

    public void goToAddQuizActivity(View view) {
        setContentView(R.layout.addquiz);
    }

    public void goToPracticeQuizActivity(View view) {
        setContentView(R.layout.practicequiz);


    }

    public void goToScoreStaticsActivity(View view) {
        setContentView(R.layout.quizstatistics);
    }

}
