package edu.gatech.seclass.sdpvocabquiz;

import java.util.Date;
import java.util.List;

/**
 * Created by dalyakhatun on 10/8/18.
 */

public class ScoreStatistics {
    private String takenBy;
    private String quizName;
    private Score firstScore;
    private Score highestScore;
    private List<String> topThree;
    private Date lastPlayedDate;

    public ScoreStatistics(String takenBy,
                           String quizName,
                           Score firstScore,
                           Score highestScore,
                           List<String> topThree,
                           Date lastPlayedDate)
    {
        this.takenBy = takenBy;
        this.quizName = quizName;
        this.firstScore = firstScore;
        this.highestScore = highestScore;
        this.topThree = topThree;
        this.lastPlayedDate = lastPlayedDate;
    }

    public void setHighestScore(Score score) {

        if (this.highestScore.compareTo(score) < 0) {
            this.highestScore = score;
        }

        return;
    }
};


