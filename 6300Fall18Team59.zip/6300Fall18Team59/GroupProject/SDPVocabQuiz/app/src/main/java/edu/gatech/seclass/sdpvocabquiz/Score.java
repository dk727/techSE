package edu.gatech.seclass.sdpvocabquiz;

import java.util.Date;

/**
 * Created by dalyakhatun on 10/8/18.
 */

public class Score implements Comparable<Score> {
    private double scorePercentage;
    private Date   date;

    public Score(double scorePercentage, Date date) {
        this.scorePercentage = scorePercentage;
        this.date = date;
    }

    @Override
    public int compareTo(Score that) {
        return this.scorePercentage - that.scorePercentage < 0 ? -1 : 1;
    }


}

