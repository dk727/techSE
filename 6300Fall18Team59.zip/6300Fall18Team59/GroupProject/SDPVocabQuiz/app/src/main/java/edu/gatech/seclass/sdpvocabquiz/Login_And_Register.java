package edu.gatech.seclass.sdpvocabquiz;

import android.support.v7.app.AppCompatActivity;

/**
 * Created by dalyakhatun on 10/8/18.
 */

public class Login_And_Register extends AppCompatActivity {
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.login);
//    }
}
